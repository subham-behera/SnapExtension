chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'capture') {
      chrome.tabs.captureVisibleTab(null, { format: 'png' }, (image) => {
        if (chrome.runtime.lastError) {
          console.error(chrome.runtime.lastError.message);
          return;
        }
  
        chrome.downloads.download({
          url: image,
          filename: 'screenshot.png'
        });
      });
    }
  });
  